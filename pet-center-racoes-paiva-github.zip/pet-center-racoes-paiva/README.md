# Pet Center Rações Paiva

Site institucional da Pet Center Rações Paiva — pet shop em Caucaia do Alto, Cotia, SP.

## Estrutura

```
.
├── index.html      # estrutura da página
├── css/
│   └── style.css   # estilos e animações
└── js/
    └── script.js   # produtos, filtros, WhatsApp e animações de rolagem
```

## Editar preços e produtos

Os produtos, categorias e preços ficam no início do arquivo `js/script.js`,
no bloco `PRODUTOS`. Também é possível trocar o número de WhatsApp ali
(constante `WHATSAPP_NUMBER`).

## Publicar no GitHub

Depois de criar um repositório vazio no GitHub:

```bash
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git branch -M main
git push -u origin main
```

## Publicar com GitHub Pages (opcional, deixa o site online de graça)

1. No GitHub, vá em **Settings → Pages**.
2. Em "Source", escolha a branch `main` e a pasta `/ (root)`.
3. Salve — o site fica disponível em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.
