document.addEventListener('DOMContentLoaded', () => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------
     Ano automático no rodapé
  --------------------------------------------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------------------------------------------
     Menu mobile
  --------------------------------------------- */
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const open = mainNav.classList.toggle('is-open');
      navToggle.classList.toggle('is-open', open);
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('is-open');
        navToggle.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------------------------------------------
     Cabeçalho: encolhe ao rolar
  --------------------------------------------- */
  const header = document.getElementById('siteHeader');
  const onScrollHeader = () => {
    if (!header) return;
    header.style.padding = window.scrollY > 30 ? '0' : '';
  };
  document.addEventListener('scroll', onScrollHeader, { passive: true });

  /* ---------------------------------------------
     Revelar seções ao rolar (IntersectionObserver)
  --------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');
  if (reduceMotion) {
    revealEls.forEach(el => el.classList.add('is-visible'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(el => io.observe(el));
  }

  // pequeno atraso escalonado entre cards de um mesmo grid
  document.querySelectorAll('.shelf-grid').forEach(grid => {
    grid.querySelectorAll('.product-card').forEach((card, i) => {
      card.style.setProperty('--i', i);
      card.style.transitionDelay = reduceMotion ? '0s' : `${i * 70}ms`;
    });
  });

  /* ---------------------------------------------
     Contadores animados (seção Sobre)
  --------------------------------------------- */
  const counters = document.querySelectorAll('[data-count]');
  const animateCount = (el) => {
    const target = parseInt(el.getAttribute('data-count'), 10) || 0;
    const suffix = el.getAttribute('data-suffix') || '';
    if (reduceMotion) { el.textContent = target + suffix; return; }
    const duration = 1400;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(eased * target) + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  if (counters.length) {
    const countIO = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          countIO.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    counters.forEach(el => countIO.observe(el));
  }

  /* ---------------------------------------------
     Filtro de produtos por categoria
  --------------------------------------------- */
  const filterBar = document.getElementById('filterBar');
  const pillIndicator = document.getElementById('pillIndicator');
  const pills = document.querySelectorAll('.pill');
  const cards = document.querySelectorAll('.product-card');
  const groups = document.querySelectorAll('[data-group]');

  const moveIndicator = (pill) => {
    if (!pillIndicator || !filterBar) return;
    const barRect = filterBar.getBoundingClientRect();
    const pillRect = pill.getBoundingClientRect();
    pillIndicator.style.width = pillRect.width + 'px';
    pillIndicator.style.transform = `translateX(${pillRect.left - barRect.left}px)`;
  };

  const applyFilter = (filter) => {
    cards.forEach(card => {
      const match = filter === 'all' || card.getAttribute('data-cat') === filter;
      card.style.display = match ? '' : 'none';
    });
    groups.forEach(group => {
      const hasVisible = filter === 'all' || group.getAttribute('data-group') === filter;
      const section = group.closest('.cat-section');
      if (section) section.style.display = hasVisible ? '' : 'none';
    });
  };

  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => { p.classList.remove('is-active'); p.setAttribute('aria-selected', 'false'); });
      pill.classList.add('is-active');
      pill.setAttribute('aria-selected', 'true');
      moveIndicator(pill);
      applyFilter(pill.getAttribute('data-filter'));
    });
  });

  const activePill = document.querySelector('.pill.is-active');
  if (activePill) {
    // aguarda fontes/layout carregarem para medir a posição certa
    window.addEventListener('load', () => moveIndicator(activePill));
    setTimeout(() => moveIndicator(activePill), 250);
  }
  window.addEventListener('resize', () => {
    const current = document.querySelector('.pill.is-active');
    if (current) moveIndicator(current);
  });

  /* ---------------------------------------------
     Links de categoria no menu ativam o filtro certo
  --------------------------------------------- */
  document.querySelectorAll('[data-nav]').forEach(link => {
    link.addEventListener('click', () => {
      const map = { '#racoes': 'racao', '#moda-pet': 'moda', '#brinquedos': 'brinquedo' };
      const target = map[link.getAttribute('href')];
      if (!target) return;
      const pill = document.querySelector(`.pill[data-filter="${target}"]`);
      if (pill) pill.click();
    });
  });
});
